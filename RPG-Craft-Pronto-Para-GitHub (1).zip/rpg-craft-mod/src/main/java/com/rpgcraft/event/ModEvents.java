package com.rpgcraft.event;

import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.command.ModCommands;
import com.rpgcraft.data.PlayerData;
import com.rpgcraft.network.ModPackets;
import com.rpgcraft.system.AttributeEffects;
import com.rpgcraft.system.ManaSystem;
import com.rpgcraft.system.SkillSystem;
import com.rpgcraft.system.XpHandler;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class ModEvents {

    public static void register() {
        ModCommands.register();
        XpHandler.register();

        // Ao morrer/respawnar o jogador é recriado: copia os dados de RPG do corpo antigo
        ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
            PlayerData oldData = ClassManager.getData(oldPlayer);
            PlayerData newData = ClassManager.getData(newPlayer);
            newData.readNbt(oldData.writeNbt());
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            AttributeEffects.apply(newPlayer);
            ManaSystem.refill(newPlayer);
        });

        // Barra de ação (HUD): vida, mana, nível e recarga das habilidades + regeneração de mana
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTicks();
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                PlayerData d = ClassManager.getData(player);
                if (!d.hasChosenClass()) continue;

                ManaSystem.tick(player);

                if (tick % 10 == 0) {
                    int mana = (int) ManaSystem.get(player);
                    String hud = "§c❤ " + (int) Math.ceil(player.getHealth()) + "/" + (int) player.getMaxHealth()
                            + "  §9✦ " + mana + "/" + ManaSystem.getMax(player)
                            + "  §6Nv." + d.getLevel() + " §7(" + (int) (d.getXpProgress() * 100) + "%)  "
                            + SkillSystem.hudCooldowns(player, d);
                    player.sendMessage(Text.literal(hud), true);
                }
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            PlayerData data = ClassManager.getData(player);

            server.execute(() -> {
                AttributeEffects.apply(player);
                ManaSystem.refill(player);

                if (!data.hasChosenClass()) {
                    player.sendMessage(Text.literal("§6§l════════════════════════════════"), false);
                    player.sendMessage(Text.literal("§6§l       ✦ Minecraft RPG V2 ✦"), false);
                    player.sendMessage(Text.literal("§eEscolha sua classe na tela que abriu"), false);
                    player.sendMessage(Text.literal("§7ou digite: §f/rpg select <classe>"), false);
                    player.sendMessage(Text.literal("§7espadachim, artesao, arqueiro, mago,"), false);
                    player.sendMessage(Text.literal("§7mineiro, assassino, paladino"), false);
                    player.sendMessage(Text.literal("§6§l════════════════════════════════"), false);
                    ServerPlayNetworking.send(player, ModPackets.OPEN_CLASS_SCREEN, PacketByteBufs.empty());
                } else {
                    player.sendMessage(Text.literal("§6§l[Minecraft RPG V2] §aBem-vindo, ")
                            .append(data.getPlayerClass().getStyledName())
                            .append(Text.literal(" §7Nv.§f" + data.getLevel())), false);
                    if (data.getAttributePoints() > 0)
                        player.sendMessage(Text.literal("§b" + data.getAttributePoints() + " Attr Points §7(/rpg attr)"), false);
                    if (data.getSkillPoints() > 0)
                        player.sendMessage(Text.literal("§e" + data.getSkillPoints() + " Skill Points §7(/rpg skill)"), false);
                }
            });
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ManaSystem.remove(handler.getPlayer().getUuid());
            SkillSystem.clearPlayer(handler.getPlayer().getUuid());
        });
    }
}
