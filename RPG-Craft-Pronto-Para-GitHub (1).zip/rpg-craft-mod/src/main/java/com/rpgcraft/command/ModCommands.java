package com.rpgcraft.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.data.PlayerData;
import com.rpgcraft.system.ManaSystem;
import com.rpgcraft.system.SkillSystem;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            registerRpgCommand(dispatcher);
        });
    }

    private static void registerRpgCommand(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("rpg")

            // /rpg select <classe>
            .then(CommandManager.literal("select")
                .then(CommandManager.argument("classe", StringArgumentType.word())
                    .executes(ctx -> {
                        ServerPlayerEntity player = ctx.getSource().getPlayer();
                        if (player == null) return 0;
                        String classId = StringArgumentType.getString(ctx, "classe");
                        PlayerClass selected = PlayerClass.fromId(classId);
                        if (selected == PlayerClass.NONE) {
                            player.sendMessage(Text.literal("§cClasses: espadachim, artesao, arqueiro, mago, mineiro, assassino, paladino"), false);
                            return 0;
                        }
                        PlayerData data = ClassManager.getData(player);
                        if (data.hasChosenClass()) {
                            player.sendMessage(Text.literal("§cVocê já escolheu uma classe!"), false);
                            return 0;
                        }
                        ClassManager.setClass(player, selected);
                        return 1;
                    }))
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) p.sendMessage(Text.literal("§e/rpg select <classe> §7| Classes: espadachim, artesao, arqueiro, mago, mineiro, assassino, paladino"), false);
                    return 1;
                }))

            // /rpg class
            .then(CommandManager.literal("class")
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    if (player == null) return 0;
                    PlayerData data = ClassManager.getData(player);
                    if (data.hasChosenClass()) {
                        player.sendMessage(Text.literal("§6Classe: ").append(data.getPlayerClass().getStyledName())
                            .append(Text.literal(" §7| Nível §f" + data.getLevel())), false);
                    } else {
                        player.sendMessage(Text.literal("§eNenhuma classe. Use §f/rpg select <classe>"), false);
                    }
                    return 1;
                }))

            // /rpg stats  (menu de status em texto)
            .then(CommandManager.literal("stats")
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    if (player == null) return 0;
                    PlayerData d = ClassManager.getData(player);
                    player.sendMessage(Text.literal("§6§l════════ Minecraft RPG V2 ════════"), false);
                    player.sendMessage(Text.literal("§7Classe: ").append(d.getPlayerClass().getStyledName()), false);
                    player.sendMessage(Text.literal("§7Nível: §f" + d.getLevel() + "  §7XP: §f" + d.getExperience() + "§8/§f" + d.getXpForNextLevel()), false);
                    player.sendMessage(Text.literal("§c❤ §f" + (int) player.getHealth() + "/" + (int) player.getMaxHealth() + "   §9✦ Mana: §f" + (int) ManaSystem.get(player) + "/" + ManaSystem.getMax(player)), false);
                    player.sendMessage(Text.literal("§eSkill Points: §f" + d.getSkillPoints() + "   §bAttr Points: §f" + d.getAttributePoints()), false);
                    player.sendMessage(Text.literal("§cFOR §f" + d.getStrength() + "  §aVIT §f" + d.getVitality() + "  §2DEX §f" + d.getDexterity() + "  §dINT §f" + d.getIntelligence()), false);
                    player.sendMessage(Text.literal("§7Skills → 1:§f" + d.getSkill1() + " §72:§f" + d.getSkill2() + " §73:§f" + d.getSkill3() + " §7Ult:§f" + d.getUltimate()), false);
                    player.sendMessage(Text.literal("§6§l═══════════════════════════"), false);
                    return 1;
                }))

            // /rpg attr <atributo>
            .then(CommandManager.literal("attr")
                .then(CommandManager.argument("atributo", StringArgumentType.word())
                    .executes(ctx -> {
                        ServerPlayerEntity player = ctx.getSource().getPlayer();
                        if (player == null) return 0;
                        PlayerData data = ClassManager.getData(player);
                        if (!data.hasChosenClass()) {
                            player.sendMessage(Text.literal("§cEscolha uma classe primeiro!"), false);
                            return 0;
                        }
                        String attr = StringArgumentType.getString(ctx, "atributo");
                        boolean ok = data.spendAttributePoint(attr);
                        if (ok) {
                            ClassManager.onAttributesChanged(player);
                            player.sendMessage(Text.literal("§a✦ Atributo +1! Restantes: §f" + data.getAttributePoints()), false);
                            player.sendMessage(Text.literal("§cFOR §f" + data.getStrength() + " §aVIT §f" + data.getVitality() + " §2DEX §f" + data.getDexterity() + " §dINT §f" + data.getIntelligence()), false);
                        } else {
                            player.sendMessage(Text.literal("§cSem pontos ou atributo inválido. Use: forca, vitalidade, destreza, inteligencia"), false);
                        }
                        return ok ? 1 : 0;
                    }))
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) {
                        PlayerData d = ClassManager.getData(p);
                        p.sendMessage(Text.literal("§eAttr Points: §f" + d.getAttributePoints() + " §7| /rpg attr <forca|vitalidade|destreza|inteligencia>"), false);
                    }
                    return 1;
                }))

            // /rpg skill
            .then(CommandManager.literal("skill")
                .then(CommandManager.literal("unlock")
                    .then(CommandManager.argument("slot", IntegerArgumentType.integer(1, 4))
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            if (player == null) return 0;
                            int slot = IntegerArgumentType.getInteger(ctx, "slot");
                            boolean ok = SkillSystem.unlockSkill(player, slot);
                            if (!ok) player.sendMessage(Text.literal("§cNão foi possível melhorar (sem pontos ou já no máximo)."), false);
                            return ok ? 1 : 0;
                        })))
                .then(CommandManager.literal("use")
                    .then(CommandManager.argument("slot", IntegerArgumentType.integer(1, 4))
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            if (player == null) return 0;
                            int slot = IntegerArgumentType.getInteger(ctx, "slot");
                            SkillSystem.activateSkill(player, slot);
                            return 1;
                        })))
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    if (player != null) SkillSystem.showSkills(player);
                    return 1;
                }))

            // /rpg help
            .then(CommandManager.literal("help")
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p == null) return 0;
                    p.sendMessage(Text.literal("§6§l[Minecraft RPG V2] Comandos:"), false);
                    p.sendMessage(Text.literal("§e/rpg select <classe> §7- Escolher classe"), false);
                    p.sendMessage(Text.literal("§e/rpg stats §7- Status completo"), false);
                    p.sendMessage(Text.literal("§e/rpg attr <atributo> §7- Distribuir atributo"), false);
                    p.sendMessage(Text.literal("§e/rpg skill §7- Ver habilidades"), false);
                    p.sendMessage(Text.literal("§e/rpg skill unlock <1-4> §7- Melhorar skill"), false);
                    p.sendMessage(Text.literal("§e/rpg skill use <1-4> §7- Ativar skill"), false);
                    p.sendMessage(Text.literal("§7Teclas das habilidades: §fZ  X  C  V §7(mude em Controles)"), false);
                    p.sendMessage(Text.literal("§e/rpg help §7- Esta ajuda"), false);
                    return 1;
                }))
        );
    }
}
