package com.rpgcraft;

import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.event.ModEvents;
import com.rpgcraft.network.ModPackets;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RPGCraftMod implements ModInitializer {
    public static final String MOD_ID = "rpgcraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Minecraft RPG V2 carregando...");

        ModPackets.registerC2SPackets();
        ModEvents.register();
        ClassManager.init();

        LOGGER.info("Minecraft RPG V2 carregado com sucesso! Use /rpg help");
    }
}
