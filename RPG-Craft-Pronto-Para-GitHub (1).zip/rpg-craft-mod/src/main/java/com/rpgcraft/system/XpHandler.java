package com.rpgcraft.system;

import com.rpgcraft.classsystem.ClassManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Responsável por dar XP de RPG ao jogador.
 */
public class XpHandler {

    public static void register() {
        // XP ao matar qualquer entidade viva
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, entity, killed) -> {
            if (!(entity instanceof ServerPlayerEntity player)) return;

            int xp = calculateXp(killed);
            if (xp > 0) {
                ClassManager.addXp(player, xp);
            }
        });
    }

    private static int calculateXp(LivingEntity killed) {
        // Base por tipo
        if (killed instanceof HostileEntity) {
            // Hostis dão mais XP
            float maxHealth = killed.getMaxHealth();

            if (maxHealth >= 100) return 80;      // Chefes / Warden etc
            if (maxHealth >= 50)  return 45;      // Evoker, Ravager...
            if (maxHealth >= 30)  return 28;      // Enderman, Iron Golem hostil...
            if (maxHealth >= 20)  return 18;      // Creeper, Skeleton, Zombie...
            return 12;                           // Mobs fracos
        }

        if (killed instanceof AnimalEntity) {
            return 4; // Animais dão pouco XP
        }

        if (killed instanceof MobEntity) {
            return 8; // Outros mobs
        }

        return 3; // Qualquer outra LivingEntity
    }
}
