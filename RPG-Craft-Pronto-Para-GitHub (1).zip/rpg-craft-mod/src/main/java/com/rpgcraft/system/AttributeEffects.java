package com.rpgcraft.system;

import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.data.PlayerData;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.UUID;

/**
 * Aplica os efeitos reais dos atributos, do nível e das passivas de classe.
 * Usa AttributeModifiers para não conflitar com outros mods.
 */
public class AttributeEffects {

    // UUIDs fixos para poder remover/atualizar os modificadores
    private static final UUID STR_DAMAGE_UUID  = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final UUID VIT_HEALTH_UUID  = UUID.fromString("b2c3d4e5-f6a7-8901-bcde-f12345678901");
    private static final UUID DEX_SPEED_UUID   = UUID.fromString("c3d4e5f6-a7b8-9012-cdef-123456789012");
    private static final UUID DEX_ATTACK_SPEED = UUID.fromString("d4e5f6a7-b8c9-0123-def0-234567890123");

    private static final UUID LVL_HEALTH_UUID  = UUID.fromString("e5f6a7b8-c9d0-1234-ef01-345678901234");
    private static final UUID CLS_DAMAGE_UUID  = UUID.fromString("f6a7b8c9-d0e1-2345-f012-456789012345");
    private static final UUID CLS_ARMOR_UUID   = UUID.fromString("a7b8c9d0-e1f2-3456-0123-567890123456");
    private static final UUID CLS_KB_UUID      = UUID.fromString("b8c9d0e1-f2a3-4567-1234-678901234567");
    private static final UUID CLS_SPEED_UUID   = UUID.fromString("c9d0e1f2-a3b4-5678-2345-789012345678");
    private static final UUID CLS_LUCK_UUID    = UUID.fromString("d0e1f2a3-b4c5-6789-3456-890123456789");
    private static final UUID CLS_HEALTH_UUID  = UUID.fromString("e1f2a3b4-c5d6-7890-4567-901234567890");

    public static void apply(ServerPlayerEntity player) {
        PlayerData data = ClassManager.getData(player);
        if (!data.hasChosenClass()) {
            clear(player);
            return;
        }

        // ===== FORÇA → dano de ataque (+0,15 por ponto) =====
        applyModifier(player, EntityAttributes.GENERIC_ATTACK_DAMAGE, STR_DAMAGE_UUID,
                "rpgcraft_strength_damage", data.getStrength() * 0.15,
                EntityAttributeModifier.Operation.ADDITION);

        // ===== VITALIDADE → vida máxima (+1 HP por ponto) =====
        applyModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, VIT_HEALTH_UUID,
                "rpgcraft_vitality_health", data.getVitality() * 1.0,
                EntityAttributeModifier.Operation.ADDITION);

        // ===== DESTREZA → velocidade de movimento e de ataque =====
        applyModifier(player, EntityAttributes.GENERIC_MOVEMENT_SPEED, DEX_SPEED_UUID,
                "rpgcraft_dexterity_speed", data.getDexterity() * 0.005,
                EntityAttributeModifier.Operation.MULTIPLY_BASE);

        applyModifier(player, EntityAttributes.GENERIC_ATTACK_SPEED, DEX_ATTACK_SPEED,
                "rpgcraft_dexterity_attack_speed", data.getDexterity() * 0.02,
                EntityAttributeModifier.Operation.ADDITION);

        // ===== NÍVEL → +0,4 de vida máxima por nível (nível 100 = +40 HP) =====
        applyModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, LVL_HEALTH_UUID,
                "rpgcraft_level_health", (data.getLevel() - 1) * 0.4,
                EntityAttributeModifier.Operation.ADDITION);

        // ===== PASSIVAS DE CLASSE =====
        double damage = 0, armor = 0, knockback = 0, speed = 0, luck = 0, health = 0;
        PlayerClass pc = data.getPlayerClass();
        switch (pc) {
            case ESPADACHIM -> { damage = 1.0; armor = 1.0; }
            case ARTESAO    -> { luck = 1.0; }
            case ARQUEIRO   -> { speed = 0.06; }
            case MAGO       -> { }
            case MINEIRO    -> { luck = 1.0; health = 4.0; }
            case ASSASSINO  -> { speed = 0.10; damage = 0.5; }
            case PALADINO   -> { armor = 3.0; knockback = 0.3; health = 4.0; }
            default -> { }
        }

        applyModifier(player, EntityAttributes.GENERIC_ATTACK_DAMAGE, CLS_DAMAGE_UUID,
                "rpgcraft_class_damage", damage, EntityAttributeModifier.Operation.ADDITION);
        applyModifier(player, EntityAttributes.GENERIC_ARMOR, CLS_ARMOR_UUID,
                "rpgcraft_class_armor", armor, EntityAttributeModifier.Operation.ADDITION);
        applyModifier(player, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, CLS_KB_UUID,
                "rpgcraft_class_knockback", knockback, EntityAttributeModifier.Operation.ADDITION);
        applyModifier(player, EntityAttributes.GENERIC_MOVEMENT_SPEED, CLS_SPEED_UUID,
                "rpgcraft_class_speed", speed, EntityAttributeModifier.Operation.MULTIPLY_BASE);
        applyModifier(player, EntityAttributes.GENERIC_LUCK, CLS_LUCK_UUID,
                "rpgcraft_class_luck", luck, EntityAttributeModifier.Operation.ADDITION);
        applyModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, CLS_HEALTH_UUID,
                "rpgcraft_class_health", health, EntityAttributeModifier.Operation.ADDITION);

        // Garante que a vida atual não fique acima do novo máximo
        if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
        }
    }

    private static void applyModifier(ServerPlayerEntity player, EntityAttribute attribute,
                                      UUID uuid, String name, double value,
                                      EntityAttributeModifier.Operation operation) {
        EntityAttributeInstance instance = player.getAttributeInstance(attribute);
        if (instance == null) return;

        instance.removeModifier(uuid);

        if (value != 0) {
            instance.addPersistentModifier(new EntityAttributeModifier(uuid, name, value, operation));
        }
    }

    /** Remove todos os modificadores do mod (jogador ainda sem classe). */
    public static void clear(ServerPlayerEntity player) {
        removeModifier(player, EntityAttributes.GENERIC_ATTACK_DAMAGE, STR_DAMAGE_UUID);
        removeModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, VIT_HEALTH_UUID);
        removeModifier(player, EntityAttributes.GENERIC_MOVEMENT_SPEED, DEX_SPEED_UUID);
        removeModifier(player, EntityAttributes.GENERIC_ATTACK_SPEED, DEX_ATTACK_SPEED);
        removeModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, LVL_HEALTH_UUID);
        removeModifier(player, EntityAttributes.GENERIC_ATTACK_DAMAGE, CLS_DAMAGE_UUID);
        removeModifier(player, EntityAttributes.GENERIC_ARMOR, CLS_ARMOR_UUID);
        removeModifier(player, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, CLS_KB_UUID);
        removeModifier(player, EntityAttributes.GENERIC_MOVEMENT_SPEED, CLS_SPEED_UUID);
        removeModifier(player, EntityAttributes.GENERIC_LUCK, CLS_LUCK_UUID);
        removeModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, CLS_HEALTH_UUID);
    }

    private static void removeModifier(ServerPlayerEntity player, EntityAttribute attribute, UUID uuid) {
        EntityAttributeInstance instance = player.getAttributeInstance(attribute);
        if (instance != null) {
            instance.removeModifier(uuid);
        }
    }
}
