package com.rpgcraft.client;

import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.network.ModPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.LinkedHashMap;
import java.util.Map;

public class ClassSelectionScreen extends Screen {

    private final Map<ButtonWidget, PlayerClass> buttons = new LinkedHashMap<>();
    private PlayerClass hoveredClass = null;

    public ClassSelectionScreen() {
        super(Text.literal("Escolha sua Classe").formatted(Formatting.GOLD, Formatting.BOLD));
    }

    @Override
    protected void init() {
        buttons.clear();

        PlayerClass[] classes = {
            PlayerClass.ESPADACHIM,
            PlayerClass.ARTESAO,
            PlayerClass.ARQUEIRO,
            PlayerClass.MAGO,
            PlayerClass.MINEIRO,
            PlayerClass.ASSASSINO,
            PlayerClass.PALADINO
        };

        int centerX = this.width / 2;
        int buttonWidth = 160;
        int buttonHeight = 20;
        int startY = 48;
        // Ajusta o espaçamento para caber em telas pequenas (celular)
        int spacing = Math.max(22, Math.min(28, (this.height - 48 - 90) / classes.length));

        for (int i = 0; i < classes.length; i++) {
            final PlayerClass pc = classes[i];
            int y = startY + (i * spacing);

            ButtonWidget button = ButtonWidget.builder(
                    Text.literal("▶ " + pc.getDisplayName()).formatted(pc.getColor()),
                    b -> selectClass(pc)
            ).dimensions(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight).build();

            this.addDrawableChild(button);
            buttons.put(button, pc);
        }
    }

    private void selectClass(PlayerClass playerClass) {
        ClientPlayNetworking.send(ModPackets.SELECT_CLASS, ModPackets.createSelectClassPacket(playerClass.getId()));
        this.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("✦ MINECRAFT RPG V2 ✦").formatted(Formatting.GOLD, Formatting.BOLD),
                this.width / 2, 12, 0xFFFFFF);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Escolha sua classe e inicie sua jornada"),
                this.width / 2, 28, 0xAAAAAA);

        hoveredClass = null;
        for (Map.Entry<ButtonWidget, PlayerClass> entry : buttons.entrySet()) {
            if (entry.getKey().isMouseOver(mouseX, mouseY)) {
                hoveredClass = entry.getValue();
            }
        }

        if (hoveredClass != null) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal(hoveredClass.getDescription()).formatted(Formatting.YELLOW),
                    this.width / 2, this.height - 24, 0xFFFFFF);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // força a escolha
    }
}
