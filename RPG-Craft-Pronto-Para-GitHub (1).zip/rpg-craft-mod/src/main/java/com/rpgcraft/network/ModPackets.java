package com.rpgcraft.network;

import com.rpgcraft.RPGCraftMod;
import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.system.SkillSystem;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public class ModPackets {
    // cliente -> servidor
    public static final Identifier SELECT_CLASS = new Identifier(RPGCraftMod.MOD_ID, "select_class");
    public static final Identifier USE_SKILL = new Identifier(RPGCraftMod.MOD_ID, "use_skill");
    // servidor -> cliente
    public static final Identifier OPEN_CLASS_SCREEN = new Identifier(RPGCraftMod.MOD_ID, "open_class_screen");

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(SELECT_CLASS, (server, player, handler, buf, responseSender) -> {
            String classId = buf.readString();
            server.execute(() -> {
                if (ClassManager.getData(player).hasChosenClass()) return;
                PlayerClass selected = PlayerClass.fromId(classId);
                if (selected != PlayerClass.NONE) {
                    ClassManager.setClass(player, selected);
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(USE_SKILL, (server, player, handler, buf, responseSender) -> {
            int slot = buf.readInt();
            server.execute(() -> {
                if (slot >= 1 && slot <= 4) {
                    SkillSystem.activateSkill(player, slot);
                }
            });
        });
    }

    public static PacketByteBuf createSelectClassPacket(String classId) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(classId);
        return buf;
    }

    public static PacketByteBuf createUseSkillPacket(int slot) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(slot);
        return buf;
    }
}
