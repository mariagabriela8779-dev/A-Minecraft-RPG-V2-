# Minecraft RPG V2

Sistema de classes RPG para **Minecraft Java 1.20.1 (Fabric)**. Id do mod: `rpgcraft` (mantido para não quebrar saves).

## Classes (7)
Espadachim, Artesão, Arqueiro, Mago, Mineiro, Assassino e Paladino.
Na primeira vez que entra no mundo, abre uma tela para escolher a classe.

## Progressão
- Nível 1 a 100. Matar monstros dá XP.
- Cada nível: +2 Skill Points, +1 Attribute Point (+1 extra a cada 5 níveis) e +0,4 de vida máxima.
- Ao subir de nível: título na tela, som, partículas, vida e mana enchem.
- Ao morrer, você mantém classe, nível, pontos e habilidades.

## Atributos
| Atributo     | Efeito                                         |
|--------------|------------------------------------------------|
| Força        | +0,15 de dano por ponto                        |
| Vitalidade   | +1 de vida máxima por ponto                    |
| Destreza     | Velocidade de movimento e de ataque            |
| Inteligência | +4 de mana máxima, regeneração de mana e menos recarga (até -50%) |

## Passivas de classe
- Espadachim: +1 dano, +1 armadura
- Artesão: +1 sorte
- Arqueiro: +6% velocidade
- Mago: +30 mana máxima e regeneração de mana 50% mais rápida
- Mineiro: +1 sorte, +2 corações
- Assassino: +10% velocidade, +0,5 dano
- Paladino: +3 armadura, resistência a empurrão, +2 corações

## Habilidades (3 skills + 1 ultimate por classe)
Gastam **mana** e têm **recarga**. Teclas padrão: **Z, X, C, V** (podem ser mudadas em Controles).

| Classe | Skill 1 | Skill 2 | Skill 3 | Ultimate |
|---|---|---|---|---|
| Espadachim | Golpe Giratório (dano em área) | Postura de Ferro | Investida (dash + dano) | Fúria de Batalha |
| Artesão | Mãos de Mestre | Forja Interior | Olho de Artesão | Inspiração Lendária |
| Arqueiro | Passo Leve | Salto do Falcão | Olho de Águia (inimigos brilham) | Caçador Supremo |
| Mago | Nova de Fogo (dano + fogo) | Barreira Arcana | Pulso Gélido (dano + lentidão) | Meteoro Arcano |
| Mineiro | Pressa das Profundezas | Pele de Pedra | Visão das Profundezas | Terremoto (dano em área) |
| Assassino | Sombras | Passo Sombrio (dash) | Golpe Mortal (dano + veneno) | Dança das Lâminas |
| Paladino | Bênção | Mão Curativa | Luz Sagrada (dano em área) | Aura Divina |

Custo de mana: 10 / 15 / 20 / 50. Recarga base: 8s / 12s / 18s / 60s.

## Tela (HUD)
A barra de ação mostra vida, mana, nível, % de XP e a recarga de cada habilidade.

## Comandos
```
/rpg select <classe>
/rpg stats
/rpg attr <forca|vitalidade|destreza|inteligencia>
/rpg skill
/rpg skill unlock <1-4>
/rpg skill use <1-4>
/rpg help
```

## Compilar
```bash
gradle build
```
Arquivo final: `build/libs/minecraft-rpg-v2-1.0.0.jar`
